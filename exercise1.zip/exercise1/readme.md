## Exercise1
### update points:
1.prettify most of the characters.

2.not only change the color but make patterns in background.

3.update the articles.
